from machine import ADC, Pin
import time

# Set up ADC pins for sensors
voltage_sensor = ADC(Pin(26))  # GP26 (ADC0)
current_sensor = ADC(Pin(27))  # GP27 (ADC1)

# Set up LED pins as outputs
voltage_led = Pin(0, Pin.OUT)  # GP0 for Voltage LED
current_led = Pin(1, Pin.OUT)  # GP1 for Current LED

# Conversion factor for 3.3V ADC (0–65535 range)
VOLTAGE_REF = 3.3 / 65535

# Scaling factors for transmission line ranges
VOLTAGE_SCALE = 240 / 3.3  # 0–3.3V to 0–240V
CURRENT_SCALE = 15 / 3.3   # 0–3.3V to 0–15A

print("Starting Transmission Line Monitoring...")
while True:
    # Read raw ADC values
    voltage_raw = voltage_sensor.read_u16()
    current_raw = current_sensor.read_u16()

    # Convert to scaled values
    voltage = voltage_raw * VOLTAGE_REF * VOLTAGE_SCALE
    current = current_raw * VOLTAGE_REF * CURRENT_SCALE

    # Clamp values to realistic ranges
    voltage = max(200, min(240, voltage))  # 200–240V
    current = max(5, min(15, current))     # 5–15A

    # Control LEDs based on thresholds
    if voltage > 230:
        voltage_led.on()  # Turn on Voltage LED
        print("High Voltage Warning!")
    else:
        voltage_led.off()  # Turn off Voltage LED

    if current > 12:
        current_led.on()  # Turn on Current LED
        print("High Current Warning!")
    else:
        current_led.off()  # Turn off Current LED

    # Print to serial monitor
    print("Voltage: {:.2f} V, Current: {:.2f} A".format(voltage, current))

    # Wait 5 seconds
    time.sleep(5)